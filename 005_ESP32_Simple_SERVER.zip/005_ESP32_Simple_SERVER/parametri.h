#ifndef _SECRETS_H_
#define _SECRETS_H_

#define MY_WIFI_SSID "Vodafone-C00300120"
#define MY_WIFI_PASS "cxeNYebTngNcdYtt"

#endif